# Docker-violations

This tool finds the violations in the docker file 